youtuber_a = "Roberta Viradona"
youtuber_b = "Pacheco X9"

visualizacoes_a = []
visualizacoes_b = []

print("Mês 0")
visualizacoes_a.append(1)
visualizacoes_b.append(1)
print(f"Visualizações do canal {youtuber_a}: {visualizacoes_a[0]}")
print(f"Visualizações do canal {youtuber_b}: {visualizacoes_b[0]}")

print("Mês 1")
visualizacoes_a.append(10)
visualizacoes_b.append(10)
print(f"Visualizações do canal {youtuber_a}: {visualizacoes_a[1]}")
print(f"Visualizações do canal {youtuber_b}: {visualizacoes_b[1]}")

print("Mês 2")
visualizacoes_a.append(1000)
visualizacoes_b.append(500)
print(f"Visualizações do canal {youtuber_a}: {visualizacoes_a[2]} lista inteira {visualizacoes_a}")
print(f"Visualizações do canal {youtuber_b}: {visualizacoes_b[2]} lista inteira {visualizacoes_b}")
