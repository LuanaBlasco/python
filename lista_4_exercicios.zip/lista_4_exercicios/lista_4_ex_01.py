cotacoes_empresa_a = []


cotacoes_empresa_a.append(100.00)
print(f"Cotação empresa A: {cotacoes_empresa_a}")

cotacoes_empresa_a.append(87.32)
print(f"Cotação empresa A: {cotacoes_empresa_a}")

cotacoes_empresa_a.append(92.45)
print(f"Cotação empresa A: {cotacoes_empresa_a}")

cotacoes_empresa_a.append(88.12)
print(f"Cotação empresa A: {cotacoes_empresa_a}")
