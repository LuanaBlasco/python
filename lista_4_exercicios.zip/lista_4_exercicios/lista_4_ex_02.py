cotacoes_empresa_a = []
cotacoes_empresa_b = []

cotacoes_empresa_a.append(100.00)
cotacoes_empresa_b.append(80.00)

print()
print(f"Cotação empresa A: {cotacoes_empresa_a}")
print(f"Cotação empresa B: {cotacoes_empresa_b}")

cotacoes_empresa_a.append(200.00)
cotacoes_empresa_b.append(90.00)
print()
print(f"Cotação empresa A: {cotacoes_empresa_a}")
print(f"Cotação empresa B: {cotacoes_empresa_b}")

cotacoes_empresa_a.append(28.30)
cotacoes_empresa_b.append(100.00)
print()
print(f"Cotação empresa A: {cotacoes_empresa_a}")
print(f"Cotação empresa B: {cotacoes_empresa_b}")

cotacoes_empresa_a.append(40.34)
cotacoes_empresa_b.append(69.78)
print()
print(f"Cotação empresa A: {cotacoes_empresa_a}")
print(f"Cotação empresa B: {cotacoes_empresa_b}")

cotacoes_empresa_a.append(78.99)
cotacoes_empresa_b.append(80.00)
print()
print(f"Cotação empresa A: {cotacoes_empresa_a}")
print(f"Cotação empresa B: {cotacoes_empresa_b}")