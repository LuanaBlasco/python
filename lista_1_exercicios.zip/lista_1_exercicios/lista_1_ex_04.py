v1 = int(input("Digite um número inteiro: "))
v2 = int(input("Digite o segundo número inteiro: "))
v3 = int(input("Dgigite o último número inteiro: "))
total = v1 + v2 + v3
print("A soma entre %i, %i e %i é %i "%(v1, v2, v3, total))