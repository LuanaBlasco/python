nome = input("Informe seu nome completo:  ")
print("Olá,", nome)