nome = input("Digite seu primeiro nome: ")
sobrenome = input("Digite seu sobrenome: ")
print(nome, sobrenome)