print("Cálculo da Área de um Triângulo")
b = float(input("Digite o valor da base do triângulo: "))
a = float(input("Digite a altura do triângulo: "))
area = (b*a)/2
print("A área do triângulo é: ", area)